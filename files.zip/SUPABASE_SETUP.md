# Connecting the booking form to Supabase

The booking form now saves every submission to a Supabase database table
called `bookings`, in addition to opening WhatsApp. Follow these steps to
finish the setup (takes about 5 minutes).

## 1. Create a Supabase project

1. Go to https://supabase.com and sign up / log in.
2. Click **New project**, give it a name (e.g. "vebrix"), set a database
   password, and choose a region close to India.
3. Wait ~1 minute for the project to finish provisioning.

## 2. Create the `bookings` table

1. In your project, open **SQL Editor** (left sidebar).
2. Click **New query**, paste the contents of `supabase-setup.sql`
   (included alongside this file), and click **Run**.
3. This creates the `bookings` table and a security policy that lets the
   public website insert new rows, but not read existing ones back.

## 3. Get your API credentials

1. Open **Settings → API** in the left sidebar.
2. Copy the **Project URL** (looks like `https://xxxxx.supabase.co`).
3. Copy the **anon / public** key (a long string starting with `eyJ...`).
   Do NOT use the `service_role` key on the website — it must stay secret.

## 4. Add the credentials to `index.html`

Open `index.html`, find this block near the bottom (inside the
`<script>` tag):

```javascript
const SUPABASE_URL = 'YOUR_SUPABASE_PROJECT_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
```

Replace the two placeholder strings with the values you copied in step 3,
then save and re-upload/deploy the file.

## 5. Test it

1. Open the website, fill in the booking form, and click **Send My
   Request**.
2. In Supabase, go to **Table Editor → bookings** — your test submission
   should appear as a new row.
3. WhatsApp will still open as before, so you get an instant notification
   in addition to the permanent database record.

## Viewing submissions later

Anyone can insert a booking, but no one can read them back using the
public (anon) key — that's intentional, for privacy/security. To view
submissions:

- Log in to your Supabase dashboard and open **Table Editor → bookings**,
  or
- Build a simple admin page later that signs in with a Supabase user
  account and reads the table (ask if you'd like this added).

## What changed on the site

- If Supabase isn't configured yet (placeholders still in place), the
  form falls back to WhatsApp-only, exactly like before, so nothing
  breaks in the meantime.
- Once configured, every submission is saved permanently to the
  `bookings` table, with a success/error message shown to the visitor.
- The booking section now has a subtle animated particle-network
  background (canvas-based, respects "reduce motion" accessibility
  settings, and has no effect on page performance elsewhere).
