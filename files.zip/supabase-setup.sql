-- =====================================================================
-- Vebrix booking form — Supabase setup
-- Run this once in your Supabase project's SQL Editor
-- (Dashboard → SQL Editor → New query → paste → Run)
-- =====================================================================

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  phone text not null,
  business_name text,
  website_type text,
  message text
);

-- Enable Row Level Security
alter table public.bookings enable row level security;

-- Allow anyone (the public website, using the anon key) to submit a booking
create policy "Public can insert bookings"
  on public.bookings
  for insert
  to anon
  with check (true);

-- NOTE: no SELECT policy is created for the anon role, so the public
-- website cannot read bookings back — only insert them. To view
-- submissions, use the Supabase Table Editor (Dashboard → Table Editor →
-- bookings) while logged in as the project owner, or query the table
-- from an authenticated/service-role context.
